<aside>
    <div class="lateral small-12 medium-4 large-4 column"> <!-- Barra lateral -->
        <div class="widget row">
            <?php dynamic_sidebar('widgets-barra-lateral'); ?>
        </div>
    </div>
</aside>
<?php get_footer(); ?>