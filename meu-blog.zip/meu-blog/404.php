<?php get_header(); ?>
    <section>
        <div class="conteudo small-12 medium-8 large-8 column"> <!-- Conteúdo -->
            <div class="post row"> <!-- 404 Not Found -->
                <div class="not-found small-12 medium-12 large-12 column">
                    <h1>404 - Not Found</h1>
                    <p>Post não encontrado.</p>
                </div>
            </div>
        </div>
    </section>
<?php get_sidebar(); ?>