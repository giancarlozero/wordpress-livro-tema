WordPress: de blogs pessoais a grandes portais - Tema para WordPress
--------------------------------------------------------------------

Tema simples de duas colunas constru�do com base no Foundation Framework.

Este tema ser� utilizado como material de estudo para uso em conjunto com o livro WordPress: de blogs pessoais a grandes portais, que est� sendo escrito por Giancarlo Silva. Ele tamb�m poder� ser usado como um tema comum em uma instala��o do WordPress, tendo todas as funcionalidades mais b�sicas perfeitamente funcionais.

Tema em desenvolvimento por Giancarlo Silva. Informa��es sobre o livro podem ser encontradas em giancarlosilva.com.br.

Licen�a
-------

Este tema para WordPress est� sendo distribu�do gratuitamente sob a 2� vers�o da licen�a GNU General Public License (GNU GPLv2), o que significa que voc� poder� alterar, personalizar e redistribuir o tema como desejar, desde que respeite os termos desta licen�a, que pode ser lida em https://wordpress.org/about/gpl/.

Voc� n�o � obrigado a comprar o meu livro para utilizar este tema.

Como instalar este tema?
------------------------

Voc� pode instalar este tema em seu site WordPress de duas maneiras:

1. Envie a pasta "/meu-blog" com todo o seu conte�do via FTP para dentro da pasta "/wp-content/themes" em sua instala��o do WordPress;
2. Acesse no Painel de Controle do WordPress a op��o "Apar�ncia > Temas". Clique no bot�o "Adicionar Novo" e depois em "Fazer upload do tema". Clique no bot�o "Selecionar arquivo" e selecione o pacote "meu-blog.zip" que voc� baixou. Aguarde o upload e depois clique em "Ativar".

Hist�rico de mudan�as/Change log:
---------------------------------

    Vers�o 0.2.0 Beta (21/09/2016) - Primeira parte da depura��o finalizada. In�cio do Beta Test p�blico.
    Vers�o 0.1.7 Alpha (21/09/2016) - Captura de tela (screenshot.png) adicionada. Defini��o das Imagens Destacadas no functions.php corrigida. Exibi��o das categorias e tags implementada.
    Vers�o 0.1.6 Alpha (21/09/2016) - Arquivos search.php e searchform.php conclu�dos. Tema pronto para depura��o do c�digo.
    Vers�o 0.1.5.2 Alpha (19/09/2016) - Template Tags faltantes adicionadas aos arquivos page.php, comments.php e 404.php.
    Vers�o 0.1.5.1 Alpha (18/09/2016) - Arquivo comments.php corrigido. Exibi��o de coment�rios implementada.
    Vers�o 0.1.5 Alpha (18/09/2016) - Arquivos sidebar.php e footer.php conclu�dos.
    Vers�o 0.1.4 Alpha (25/08/2016) - Arquivos single.php, comments.php, page.php e 404.php conclu�dos.
    Vers�o 0.1.3 Alpha (14/08/2016) - Arquivos index.php e archive.php conclu�dos.
    Vers�o 0.1.2 Alpha (28/07/2016) - Menu conclu�do apenas para a parte Desktop. Falta consertar a vers�o mobile do menu.
    Vers�o 0.1.1.1 Alpha (27/07/2016) - Passo 01 do tutorial refeito.
    Vers�o 0.1.1 Alpha (15/07/2016) - Foundation Framework 6 substitu�do pelo Foundation Framework 5 (acho mais f�cil criar o menu responsivo usando esta vers�o). Reconstruindo o projeto e corrigindo o c�digo.
    Vers�o 0.1.0 Alpha (07/04/2016) - Passo 01 do tutorial conclu�do. Modifica��o em informa��es importantes no README.
    Vers�o 0.0.5 Alpha (01/04/2016) - Estrutura da home, de posts e de p�ginas conclu�da.
    Vers�o 0.0.4 Alpha (29/03/2016) - Identidade visual criada. Pequena mudan�a no texto do README.
    Vers�o 0.0.3 Alpha (25/03/2016) - Estrutura de posts e p�ginas iniciada. Ajustes na estrutura da home. Menu adicionado. Webfonts adicionadas.
    Vers�o 0.0.2 Alpha (21/03/2016) - Estrutura da home iniciada.
    Vers�o 0.0.1 Alpha (21/03/2016) - In�cio da cria��o do c�digo em HTML5. Defini��o da licen�a.
